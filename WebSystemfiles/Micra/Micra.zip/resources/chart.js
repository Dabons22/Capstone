function loadData(){

    var xhttp = new XMLHttpRequest()
    xhttp.onreadystatechange = function(){
        if(this.readyState == 4 &&  this.status == 200){
                console.log(this.responseText)
                const getData = JSON.parse(this.responseText)
                const totalReport = getData.TotalReports
                const totalFinished = getData.TotalFinished
                const totalOngoing = getData.TotalOngoing


                //Data from Database
                const totalKey = Object.keys(totalReport)
                const totalReportValue = Object.values(totalReport)
                const totalOngoingValue = Object.values(totalOngoing)
                const totalFinishedValue = Object.values(totalFinished)

                //Chart Configuration
                const data = {
                    labels: totalKey,
                    datasets: [
                        {
                            label: 'Total Number of Ongoing Reports',
                            data: totalOngoingValue,
                            backgroundColor: [
                                'rgba(255, 99, 132, 0.2)'
                            ],
                            borderColor:[
                                'rgb(255, 99, 132)'

                            ],
                            borderWidth: 1
                        },
                        {
                            label: 'Total Number of Finished Reports',
                            data: totalFinishedValue,
                            backgroundColor: [
                                'rgba(75, 192, 192, 0.2)'
                            ],
                            borderColor:[
                                'rgb(75, 192, 192)'

                            ],
                            borderWidth: 1
                        }
                    ]
                }
                const config = {
                    type: 'bar',
                    data:data,
                    options: {
                        scales: {
                            y: {
                                suggestedMax: 15,
                                beginAtZero: true
                            }
                        }
                    }
                }
                const reportChart = new Chart(document.getElementById('totalReport'),config)

                //When selection has been change
                /*const sortBy = document.getElementById('sortBy')
                sortBy.addEventListener('change',function(){
                    const sortValue = this.value
                    if(sortValue === 'Month'){
                        reportChart.data.labels = monthKeys
                        reportChart.data.datasets[0].data = monthValues
                        reportChart.update()
                    }
                    else{
                        reportChart.data.labels = dayKeys
                        reportChart.data.datasets[0].data = dayValues
                        reportChart.update()
                    }
                })*/

            }
    }
    xhttp.open('POST','../process/chartData.php',true);
    xhttp.send()
}
loadData()

