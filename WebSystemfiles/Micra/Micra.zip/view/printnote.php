<?php 

    require '../controller/loginController.php';

    session_start();
    if(!isset($_SESSION['username']) and !isset($_SESSION['id'])){
        header('Location: login.php');
    }
    
    $id = $_GET['print'];

    $controller = new LoginController();
    $data = $controller->showLogs();
    $print = $controller->showprint($id);
    
    $path = '../resources/files/narrative';
    $dh = dir($path);
    $realpath = $path.'/'.$print;
    $openFile = fopen($realpath,'r');
?>

<!----------- Header ----------->
<?php include '../resources/header/header.php' ?>
<?php include '../resources/header/navigation.php' ?>

<!----------- Main Body ----------->


           <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>  
		   <script type="text/javascript" src="https://unpkg.com/xlsx@0.15.1/dist/xlsx.full.min.js"></script>
<body>
    <div class=" container p-5 shadow" id="notes">
        <?=fread($openFile,filesize($realpath));?>
        <?php fclose($openFile); ?>
    </div>

                                    <div class="modal-footer">
                                        <a href="index.php"> <button type="button" class="btn"><i class="bi bi-arrow-left-circle"></i>BACK  </button> </a>
                                        <a href="mail2.php"> <button type="button" class="btn"><i class="bi bi-send"></i>E-mail  </button> </a>
		                                <a><button type="button" id="btn-export" class="btn" onclick="exportHTML();"> <i class="bi bi-filetype-doc"></i></i>Export Word</button></a>
                                        <button type="button" class="btn"id="pdf" onclick="printDiv('notes')"><i class="bi bi-printer"></i> Print</button>    
                                    </div>

    	<!----------- WORD ----------->
	<script>
    function exportHTML(){
       var header = "<html xmlns:o='urn:schemas-microsoft-com:office:office' "+
            "xmlns:w='urn:schemas-microsoft-com:office:word' "+
            "xmlns='http://www.w3.org/TR/REC-html40'>"+
            "<head><meta charset='utf-8'><title>Export HTML to Word Document with JavaScript</title></head><body>";
      
       var sourceHTML = header+document.getElementById('notes').innerHTML;
       
       var source = 'data:application/vnd.ms-word;charset=utf-8,' + encodeURIComponent(sourceHTML);
       var fileDownload = document.createElement("a");
       document.body.appendChild(fileDownload);
       fileDownload.href = source;
       fileDownload.download = 'Report.doc';
       fileDownload.click();
       document.body.removeChild(fileDownload);
    }
</script>

    }
</script>
<!----------- print/pdf ----------->
<script>
		function printDiv(divName){
			var printContents = document.getElementById(divName).innerHTML;
			var originalContents = document.body.innerHTML;

			document.body.innerHTML = printContents;

			window.print();

			document.body.innerHTML = originalContents;

		}
	</script>

	





<!----------- Footer ----------->
<?php include '../resources/footer/footer.php'; ?>