<?php 

    require '../controller/tableController.php';

    session_start();
    if(!isset($_SESSION['username']) and !isset($_SESSION['id'])){
        header('Location: login.php');
    }



?>
<!----------- Header ----------->
<?php include '../resources/header/header.php' ?>
<?php include '../resources/header/navigation.php' ?>


<?php
$statusMsg='';
if(isset($_FILES["file"]["name"])){
   $email = $_POST['email'];
    $name = $_POST['name'];
    $subject = $_POST['subject'];
    $message = $_POST['message'];
$fromemail =  "itvengersdatabase.ver.2@gmail.com";
$subject=$subject;
$email_message = '<h2>CASE REPORT UPDATE</h2>
                    <p><b>Name:</b> '.$name.'</p>
                    <p><b>Email:</b> '.$email.'</p>
                    <p><b>Subject:</b> '.$subject.'</p>
                    <p><b>Message:</b><br/>'.$message.'</p>';
$email_message.="Thank You!";
$semi_rand = md5(uniqid(time()));
$headers = "From: ".$fromemail;
$mime_boundary = "==Multipart_Boundary_x{$semi_rand}x";
 
    $headers .= "\nMIME-Version: 1.0\n" .
    "Content-Type: multipart/mixed;\n" .
    " boundary=\"{$mime_boundary}\"";
 
if($_FILES["file"]["name"]!= ""){  
	$strFilesName = $_FILES["file"]["name"];  
	$strContent = chunk_split(base64_encode(file_get_contents($_FILES["file"]["tmp_name"])));  
	
	
    $email_message .= "This is a multi-part message in MIME format.\n\n" .
    "--{$mime_boundary}\n" .
    "Content-Type:text/html; charset=\"iso-8859-1\"\n" .
    "Content-Transfer-Encoding: 7bit\n\n" .
    $email_message .= "\n\n";
 
 
    $email_message .= "--{$mime_boundary}\n" .
    "Content-Type: application/octet-stream;\n" .
    " name=\"{$strFilesName}\"\n" .
    //"Content-Disposition: attachment;\n" .
    //" filename=\"{$fileatt_name}\"\n" .
    "Content-Transfer-Encoding: base64\n\n" .
    $strContent  .= "\n\n" .
    "--{$mime_boundary}--\n";
}
$toemail=$email;	
 
if(mail($toemail, $subject, $email_message, $headers)){
   $statusMsg= "Email sent successfully!!";
}else{
   $statusMsg= "Not sent";
}
}
   
   ?>
   
<!DOCTYPE html>
<html>
    <head><title>SEND EMAIL </title>
     <link rel ="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.14.0/css/all.min.css" />
    <style>
        /* Style inputs with type="text", select elements and textareas */
input[type=text], select, textarea {
  width: 100%; /* Full width */
  padding: 12px; /* Some padding */ 
  border: 1px solid #ccc; /* Gray border */
  border-radius: 4px; /* Rounded borders */
  box-sizing: border-box; /* Make sure that padding and width stays in place */
  margin-top: 6px; /* Add a top margin */
  margin-bottom: 16px; /* Bottom margin */
  resize: vertical /* Allow the user to vertically resize the textarea (not horizontally) */
  font: helvetica;
}
.placeholder{
    font: helvetica;
}
/* Style the submit button with a specific background color etc */
input[type=submit] {
  background-color: #cd5c5c;
  color: white;
  padding: 12px 20px;
  border: none;
  border-radius: 4px;
  cursor: pointer;
}
input[type=file] {
  background-color: #808080;
  color: white;
  padding: 12px 20px;
  border: none;
  border-radius: 4px;
  cursor: pointer;
  font color: black;
}
form{
    font-family: helvetica;
    font-weight: bold;
    margin-left: 100px;
    margin-right: 400px;
  }

/* When moving the mouse over the submit button, add a darker color */
button[type=submit]:hover {
  background-color: #e60026;
  
}
button[type=button]:hover {
  background-color: #e60026;
}
/* Add a background color and some padding around the form */

.button {
  background-color: #8CCDC2; /* Green */
  border: none;
   border-radius: 4px;
  color: white;
  padding: 8px 15px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 16px;
  margin: 4px 2px;
  transition-duration: 0.4s;
  cursor: pointer;
  font:helvetica;
}
.button1 {
  background-color:#ed2939;
  font:helvetica;
  color: white;
    border: 2px solid #ed2939;
}
.button1:hover {
  font:helvetica;
  background-color: white;
  color: black;
}
 .button2 {
    font:helvetica;
  background-color: #cd5c5c;
  color: white;
  border: 2px solid #cd5c5c;
   border-radius: 4px;
}
h1{

    margin-left: 100px;
    margin-right: 400px;
  }
  
 p{
	background:#15a869;
	border:1px solid #15a869;
	color:#ffffff;
	width:21%;
	margin-left: 100px;
    margin-right: 400px;
     font-size: 25px;
     border-radius: 4px;
}
    </style></head>
    <body>
        
        <!-- Display submission status -->
<?php if(!empty($statusMsg)){ ?>
    <p "><?php echo $statusMsg; ?></p>
<?php } ?>
 
<!-- Display contact form -->
<h1>SEND EMAIL</h1>
<form method="post" action="" enctype="multipart/form-data">
    <div class="form-group">
        <input type="text" name="name" class="form-control"  placeholder="Name" required="">
    </div>
    <div class="form-group">
        <input type="text" name="email" class="form-control"  placeholder="Email address" required="">
    </div>
    <div class="form-group">
        <input type="text" name="subject" class="form-control"  placeholder="Subject" required="">
    </div>
    <div class="form-group">
        <textarea name="message"  class="form-control" placeholder="Message" required=""></textarea>
    </div>
    <div class="form-group">
        <input type="file" name="file" class="form-control">
    </div><br><ln></ln>
    <div class="submit">
        <a href="finish_report.php"> <button type="button" class="button button2"><i class="fas fa-arrow-alt-circle-left"></i> BACK  </button> </a>
        <button type="submit" name="submit" class="button button2"value="SEND EMAIL"><i class="fa fa-paper-plane fw-fa"></i> SEND EMAIL  </button>
         
    </div>
</form>
 
</body>
 <!----------- Footer ----------->
<?php include '../resources/footer/footer.php'; ?>
</html>