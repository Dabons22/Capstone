<?php
    require '../controller/adminController.php';
    session_start();
    if(!isset($_SESSION['username']) and !isset($_SESSION['id'])){
        header('Location: login.php');
    }

    $controller = new AdminController;
    $data = $controller->getAccount();

?>
<!----------- Header ----------->
<?php include '../resources/header/header.php' ?>
<?php include '../resources/header/navigation.php' ?>

<!----------- Main Body ----------->
<body>
    <div class="container p-5 shadow mb-3">
        <h4 class="fs-5 fw-bold mb-4">Create new Admin Account</h4>
        <div class="container border border-2 p-3">
            <form id="addAdmin">
                <div class="row mb-3">
                    <div class="col">
                        <label for="firstname" class="form-label">Firstname</label>
                        <input type="text" class="form-control" name="firstname" id="firstname" placeholder="Pangalan" required>
                    </div>
                    <div class="col">
                        <label for="lastname" class="form-label">Lastname</label>
                        <input type="text" class="form-control" name="lastname" id="lastname" placeholder="Apelyido" required>
                    </div>
                </div>
                <div class="row mb-3">
                    <div class="col">
                        <label for="position" class="form-label">Position</label>
                        <select class="form-select" id="position" name="position">
                            <option value="Main Administrator">Main Administrator</option>
                            <option value="Incident Head">Crime Head</option>
                            <option value="Infrastructure Head">Infrastructure Head</option>
                            <option value="Waste Head">Waste Head</option>
                        </select>
                    </div>
                </div>
                <div class="row mb-3">
                    <div class="col">
                        <label for="email" class="form-label">Email</label>
                        <span id="emailerror"></span>
                        <input type="email" class="form-control" name="email" id="email" placeholder="example@micra.com" required>
                    </div>
                    <div class="col">
                        <label for="contact" class="form-label">Contact Number</label>
                        <span id="contacterror"></span>
                        <input type="text" class="form-control" name="contact" id="contact" placeholder="Contact Number" required>
                    </div>
                </div>
                <div class="row mb-3">
                    <div class="col">
                        <label for="username" class="form-label">Username</label>
                        <span id="usernameerror"></span>
                        <input type="text" class="form-control" name="username" id="username" placeholder="Your Username" required>
                    </div>
                    <div class="col">
                        <label for="password" class="form-label">Password</label>
                        <input type="password" minlength="8" maxlength="16" class="form-control" name="password" id="password" placeholder="Minimum of 8 characters and maximum of 16 characters." autocomplete="off" required>
                    </div>
                </div>
                <button type="submit" class="btn form-control form-control-lg" name="submit" id="submit" value="subit">Create Account</button>
            </form>
        </div>
    </div>
    
        <div class="container shadow mt-4 p-5">
        <h4 class="fs-5 fw-bold mb-4">List of Admins</h4>
        <div class="allAccounts">
        <div class="accordion" id="permissions">
            <?php while($row = $data->fetch_assoc()){ ?>
            <div class="accordion-item">
                <h5 class="accordion-header" id="account<?=$row['ID']?>">
                    <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#adminAccount<?=$row['ID']?>" aria-expanded="false" aria-controls="adminAccount<?=$row['ID']?>">
                        <?= $row['USERNAME']?>
                    </button>
                </h5>
                <div id="adminAccount<?=$row['ID']?>" class="accordion-collapse collapse" aria-labelledby="account<?=$row['ID']?>" data-bs-parent="#permissions">
                    <div class="accordion-body">
                        <div class="p-4 border mb-3">
                            <h5 class="fs-6">Name :<?=' '.$row['FULLNAME']?> </h5>
                            <h5 class="fs-6">Email :<?=' '.$row['EMAIL']?></h5>
                            <h5 class="fs-6">Contact :<?=' '.$row['CONTACT']?></h5>
                            <div class="d-flex" name="positionContainer">
                                <h5 class="fs-6">Position: <?=' '.$row['UROLE']?></h5>
                                <span>
                                    <button type="button" class="btn btn-sm" name="editPosition"><i class="bi bi-pen"></i></button>
                                </span>
                            </div>
                        </div>

                    </div>
                </div>
            </div>
            <?php } ?>
        </div>
        </div>
    </div>
    

    <div class="toast-container">
        <div class="position-fixed bottom-0 end-0 p-3" style="z-index: 11">
            <div id="successToast" class="toast" role="alert" aria-live="assertive" aria-atomic="true">
                <div class="toast-header">
                    <strong class="me-auto">Micra Administrator</strong>
                    <small id="timeNow"></small>
                    <button type="button" class="btn-close" data-bs-dismiss="toast" aria-label="Close"></button>
                </div>
                <div class="toast-body">
                    New Admin account has been added !
                </div>
            </div>
        </div>
    </div>
    
    <?php 
        require '../process/accessDenied.php';
        
        $denied = new AccessDenied();
        $denied->isDeny($_SESSION['position']);
    ?>
<script>
    $(document).ready(function(){
        $('button[name="editPosition"]').hide()
        $('#addAdmin').submit(function(event){
            event.preventDefault();

            var send = $.post('../process/addAdmin.php',{
                username: $('#username').val(),
                password: $('#password').val(),
                email: $('#email').val(),
                firstname: $('#firstname').val(),
                lastname: $('#lastname').val(),
                position: $('#position').val(),
                contact: $('#contact').val()
            })

            send.done(function(data){
                $("#addAdmin").trigger('reset')
                console.log(data)

                switch(data){
                    case 'username':
                        $('#usernameerror').append('<small class="minimum text-danger">*Username is already used</small>')
                    case 'contact':
                        $('#contacterror').append('<small class="minimum text-danger">*Contact Number is already used</small>')
                    case 'email':
                        $('#emailerror').append('<small class="minimum text-danger">*Email is already used</small>')
                        break
                    default:
                        var successToast = $('#successToast')
                        var toast = new bootstrap.Toast(successToast)
                        document.getElementById('timeNow').innerHTML = formatAMPM(new Date())
                        toast.show()

                    }
                
                $( "#allAccounts" ).load(window.location.href + " #allAccounts" )
                
            })
        })

        function formatAMPM(date) {
            var hours = date.getHours();
            var minutes = date.getMinutes();
            var ampm = hours >= 12 ? 'pm' : 'am';
            hours = hours % 12;
            hours = hours ? hours : 12; // the hour '0' should be '12'
            minutes = minutes < 10 ? '0'+minutes : minutes;
            var strTime = hours + ':' + minutes + ' ' + ampm;
            return strTime;
        }
        
        $('div[name="positionContainer"]').mouseover(function(){
            $('button[name="editPosition"]').show()
        })
        
        $('div[name="positionContainer"]').mouseout(function(){
            $('button[name="editPosition"]').hide()
        })
        
        $('button[name="editPosition"]').click(function(){
            $('h5[name="changePosition"]').show()
            $('div[name="positionContainer"]').hide()
        })
    })
</script>
<!----------- Footer ----------->
<?php include '../resources/footer/footer.php'; ?>