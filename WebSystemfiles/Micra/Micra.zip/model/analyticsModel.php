<?php

    require '../config.php';
    
    class Analytics extends Database{
        public function connect(){
            
            $connection = new mysqli($this->servername,$this->username,$this->password,$this->database);
        
            if(!$connection->connect_error){
                return $connection;
            }
        }
        
        public function incidentData(){
            $connection = $this->connect();
            
            $stmt = $connection->prepare("SELECT reportdate FROM tblincident");
            $stmt->execute();
            
            
        }
    }