<?php 

    require '../config.php';

    class TableModel extends Database{

        public function __constuct(){
            
            return $this->connect();
        }

        public function connect(){
            $connection = new mysqli($this->servername,$this->username,$this->password,$this->database);
            
            if(!$connection->connect_error){
                return $connection;
            }
        }

        //SELECT

        public function incidentReport(string $status){
            $connection = $this->connect();
            
            $stmt = $connection->prepare("SELECT * FROM tblincident WHERE resolvestatus=?");
            $stmt->bind_param('s',$status);
            $stmt->execute();

            $result = $stmt->get_result();
            
            return $result;
        }

        public function wasteReport(string $status){
            $connection = $this->connect();

            $stmt = $connection->prepare("SELECT * FROM tblwaste WHERE status=?");
            $stmt->bind_param('s',$status);
            $stmt->execute();

            $result = $stmt->get_result();

            return $result;
        }

        public function infraReport(string $status){
            $connection = $this->connect();

            $stmt = $connection->prepare("SELECT * FROM tblinfra WHERE resolvestatus=?");
            $stmt->bind_param('s',$status);
            $stmt->execute();

            $result = $stmt->get_result();

            return $result;
        }


        //Functions for Updating Report status from Pending to Ongoing

        public function updateIncident($id,$status){
            $connection = $this->connect();

            $stmt = $connection->prepare("UPDATE tblincident SET resolvestatus=? WHERE reportnumber=?");
            $stmt->bind_param("si",$status,$id);
            $stmt->execute();

        }

        public function updateInfra($id,$status){
            $connection = $this->connect();

            $stmt = $connection->prepare("UPDATE tblinfra SET resolvestatus=? WHERE reportnumber=?");
            $stmt->bind_param("si",$status,$id);
            $stmt->execute();

        }

        public function updateWaste($id,$status){
            $connection = $this->connect();

            $stmt = $connection->prepare("UPDATE tblwaste SET status=? WHERE reportnumber=?");
            $stmt->bind_param("si",$status,$id);
            $stmt->execute();

        }

        //Functions for Updating Report Status from Ongoing to finished and send a Feedback to the Reporter

        public function finishedIncident($id,$message,$date,$time,string $status){
            $connection = $this->connect();

            $stmt = $connection->prepare("UPDATE tblincident SET resolvetime=? , resolvedate=? , resolvefeedback=? , resolvestatus=? WHERE reportnumber=?");
            $stmt->bind_param('ssssi',$time,$date,$message,$status,$id);
            $stmt->execute();
        }

        public function finishedInfra($id,$message,$date,$time,string $status){
            $connection = $this->connect();

            $stmt = $connection->prepare("UPDATE tblinfra SET resolvetime=? , resolvedate=? , resolvefeedback=? , resolvestatus=? WHERE reportnumber=?");
            $stmt->bind_param('ssssi',$time,$date,$message,$status,$id);
            $stmt->execute();
        }

        public function finishedWaste($id,$message,$date,$time,string $status){
            $connection = $this->connect();

            $stmt = $connection->prepare("UPDATE tblwaste SET feedback=? , status=? , resolvedate=? , resolvetime=? WHERE reportnumber=?");
            $stmt->bind_param('ssssi',$message,$status,$date,$time,$id);
            $stmt->execute();
        }
        
        //Get user Email and Contact Number
        
        public function getUserContact($id){
            $connection = $this->connect();
            
            $stmt = $connection->prepare("SELECT number FROM tbregister WHERE id=?");
            $stmt->bind_param('i',$id);
            $stmt->execute();
            
            $stmt->bind_result($contact);
            $result = "";
            while($stmt->fetch()){
                $result = $contact;
            }
            
            return $result;
        }
        
                
        public function getUserEmail($id){
            $connection = $this->connect();
            
            $stmt = $connection->prepare("SELECT email FROM tbregister WHERE id=?");
            $stmt->bind_param('i',$id);
            $stmt->execute();
            
            $stmt->bind_result($email);
            $result = "";
            while($stmt->fetch()){
                $result = $email;
            }
            
            return $result;
        }
        

    }